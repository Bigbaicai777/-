package Service.impl;

import Dao.*;
import Dao.impl.TeaDaoImpl;
import Service.TeaService;
import pojo.Teacher;

public class TeaServiceImpl implements TeaService{
	TeaDao t=new TeaDaoImpl(); 
	public Teacher Login(String username,String pwd) {
		return t.loginDao(username, pwd);
	}
	@Override
	public void upGrade(int student_id,int chose_grade,int blank_grade, int fin_grade) {
		t.upGrade(student_id,chose_grade,blank_grade,fin_grade);
	}
}
