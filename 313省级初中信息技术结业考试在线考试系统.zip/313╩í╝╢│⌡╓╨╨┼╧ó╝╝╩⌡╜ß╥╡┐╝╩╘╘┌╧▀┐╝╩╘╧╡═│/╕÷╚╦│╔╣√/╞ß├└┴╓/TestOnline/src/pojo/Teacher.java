package pojo;

public class Teacher {
		private int teacher_id;
		private String username;//��¼��
		private String password;
		private String name;//����
		public int getTeacher_id() {
			return teacher_id;
		}
		public void setTeacher_id(int teacher_id) {
			this.teacher_id = teacher_id;
		}
		public String getUsername() {
			return username;
		}
		public void setUsername(String username) {
			this.username = username;
		}
		public String getPassword() {
			return password;
		}
		public void setPassword(String password) {
			this.password = password;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public Teacher(int teacher_id, String username, String password, String name) {
			super();
			this.teacher_id = teacher_id;
			this.username = username;
			this.password = password;
			this.name = name;
		}
		public Teacher() {
			super();
		}
		@Override
		public String toString() {
			return "Teacher [teacher_id=" + teacher_id + ", username=" + username + ", password=" + password + ", name="
					+ name + "]";
		}
		
}
