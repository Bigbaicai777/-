package pojo;

public class Question {
	private int id;
	private String question;
	private String anser;
	private String A;
	private String B;
	private String C;
	private String D;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getQuestion() {
		return question;
	}
	public void setQuestion(String question) {
		this.question = question;
	}
	public String getAnser() {
		return anser;
	}
	public void setAnser(String anser) {
		this.anser = anser;
	}
	
	public String getA() {
		return A;
	}
	public void setA(String a) {
		A = a;
	}
	public String getB() {
		return B;
	}
	public void setB(String b) {
		B = b;
	}
	public String getC() {
		return C;
	}
	public void setC(String c) {
		C = c;
	}
	public String getD() {
		return D;
	}
	public void setD(String d) {
		D = d;
	}
	public Question(int id, String question,String anser) {
		super();
		this.question = question;
		this.anser = anser;
	}
	public Question() {
		super();
	}
	@Override
	public String toString() {
		return "Question [question=" + question + ", anser=" + anser + ", A=" + A
				+ ", B=" + B + ", C=" + C + ", D=" + D + "]";
	}

	
}
