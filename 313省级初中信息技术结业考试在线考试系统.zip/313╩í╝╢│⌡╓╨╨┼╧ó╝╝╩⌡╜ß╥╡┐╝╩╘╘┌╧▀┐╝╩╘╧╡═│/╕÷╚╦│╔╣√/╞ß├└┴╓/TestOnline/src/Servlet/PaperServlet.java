package Servlet;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Random;
import java.math.*;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Service.*;
import Service.impl.TeaServiceImpl;
import pojo.*;
import sql.sql_data;

/**
 * Servlet implementation class TeaServlet
 */
@WebServlet("/PaperServlet")
public class PaperServlet extends HttpServlet {
	TeaService t=new TeaServiceImpl(); 
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String oper=null;
		oper=req.getParameter("oper");
		if("login".equals(oper)) {
			//��¼����
			Teacher t=login(req,resp);
			
			if(t!=null) {
				resp.sendRedirect("./student/main.jsp");
			}else {
				System.out.println("�˺Ż����������");
				
			}
		}else if("delete".equals(oper)) {
			sql_data db = new sql_data();
			String id = req.getParameter("aa");
			String paper_id = req.getParameter("bb");
			String sql = "delete from paper where id = '"+id+"'";
			db.executeDelete(sql);
			resp.sendRedirect("./teacher/edit_paper.jsp?aa="+paper_id+"");
			System.out.println(sql);
		}else if("addqus".equals(oper)) {
			sql_data db= new sql_data();
			String id = req.getParameter("aa");
			String paper_id = req.getParameter("bb");
			String type = req.getParameter("type");
			String sql = "insert into paper(paper_id,"+type+"_id) values("+paper_id+","+id+")";
			System.out.println(sql);
			db.executeInsert(sql);
			resp.sendRedirect("./teacher/edit_paper.jsp?aa="+paper_id+"");
		}else if("AutoPaper".equals(oper)) {
			String chose_num = req.getParameter("chose_num");
			String blank_num = req.getParameter("blank_num");
			sql_data db = new sql_data();
			String sql_chose = "select * from chose";
			String sql_blank = "select * from blank";
			ResultSet rs = null;
			ResultSet rs_2 = null;
			rs = db.executeQuery("select count(*) as rowCount from chose");
			//�õ�chose������
			int chose_rowCount=0;
			try {
				rs.next();
				chose_rowCount = rs.getInt("rowCount");
			}catch(Exception e) {
				e.printStackTrace();
			}
			rs = db.executeQuery("select count(*) as rowCount from blank");
			//�õ�blank������
			int blank_rowCount=0;
			try {
				rs.next();
				blank_rowCount = rs.getInt("rowCount");
			}catch(Exception e) {
				e.printStackTrace();
			}
			int num = Integer.parseInt(chose_num);
			
			int chose_step = chose_rowCount/num; //chose�Ĳ���
			num = Integer.parseInt(blank_num);
			int blank_step = blank_rowCount/num;//blank�Ĳ���
			int paper_id = 1000;
			for(int i=1;i<1000;i++) {//�õ��Ծ������
				String sql_id = "select * from paper where paper_id = '"+i+"'";
				rs = db.executeQuery(sql_id);
				try {
					if(!rs.next()) {
						paper_id = i;
						break;
					}
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			System.out.println("paper_id:"+paper_id);
			rs_2 = db.executeQuery("select count(*) as rowCount from chose");
			rs = db.executeQuery(sql_chose);
			rs_2 = db.executeQuery(sql_blank);
			//����ѡ����
			try {
				Random ra = new Random();
				int pos = ra.nextInt(chose_step)+1;//�������ѡ����Ϊstep*num<=rowCount������һ����������
				int i = Integer.parseInt(chose_num);//������ֻ������ô�����
				while(rs.next()) {
					pos--;
					if(pos==0) {
						i--;
						int chose_id = rs.getInt("chose_id");
						//System.out.println(pos);
						String sql_in = "insert into paper(paper_id,chose_id) values("+paper_id+","+chose_id+")";
						//System.out.println(sql_in);
						db.executeInsert(sql_in);
						pos = ra.nextInt(chose_step)+1;
						if(i==0)break;
					}
				}//while
			}catch(Exception e) {
				e.getStackTrace();
			}//catch
			//���������
			try {
				Random ra = new Random();
				int pos = ra.nextInt(blank_step)+1;
				int i = Integer.parseInt(blank_num);
				while(rs_2.next()) {
					pos--;
					if(pos==0) {
						i--;
						int blank_id = rs_2.getInt("blank_id");
						//System.out.println(pos);
						String sql_in = "insert into paper(paper_id,blank_id) values("+paper_id+","+blank_id+")";
						//System.out.println(sql_in);
						db.executeInsert(sql_in);
						pos = ra.nextInt(chose_step)+1;
						if(i==0)break;
					}
				}//while
			}catch(Exception e) {
				e.getStackTrace();
			}//catch
			String paper_name = req.getParameter("paper_name");
			paper_name = new String(paper_name.getBytes("ISO-8859-1"),"UTF-8");
			String teacher_id = req.getParameter("teacher_id");
			String start_time = req.getParameter("start_time");
			String end_time = req.getParameter("end_time");
			String sql_info = "insert into paper_info(paper_id,paper_name,start_time,teacher_id,end_time) values( '" +paper_id+ "' , '" +paper_name+ "' , '" +start_time+ "' , '" +teacher_id+ "' , '" +end_time+ "' ) ";
			db.executeInsert(sql_info);
			//System.out.println(sql_info);
			resp.sendRedirect("./teacher/preview_paper.jsp?aa="+paper_id+"");
		}
	}

	private  Teacher login(HttpServletRequest req, HttpServletResponse resp) {
		String username=req.getParameter("username");
		String pwd=req.getParameter("pwd");
		return t.Login(username, pwd);
	}

}
