package Servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Service.*;
import Service.impl.TeaServiceImpl;
import pojo.*;
import util.sql_data;

/**
 * Servlet implementation class TeaServlet
 */
@WebServlet("/TeaServlet")
public class TeaServlet extends HttpServlet {
	TeaService ts=new TeaServiceImpl(); 
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		req.setCharacterEncoding("utf-8");
		resp.setContentType("text/html;charset=utf-8");
		String oper=null;
		oper=req.getParameter("oper");
		if("login".equals(oper)) {
			//��¼����
			Teacher t=login(req,resp);
			if(t!=null) {
				HttpSession hs=req.getSession();
				hs.setAttribute("teacher", t);
				resp.sendRedirect("./teacher/main.jsp");
			}else {
				System.out.println("�˺Ż����������");	
				}
			}else if("AddStudent".equals(oper)) {
				sql_data db = new sql_data();
				String username = req.getParameter("username");
				String name = req.getParameter("name");
				String password = req.getParameter("password");
				name = new String(name.getBytes("ISO-8859-1"),"UTF-8");
				String sql = "insert into student(username,password,name) values('"+username+"','"+password+"','"+name+"')";
				db.executeInsert(sql);
				resp.sendRedirect("./teacher/studentmanage.jsp");
				System.out.println(sql);
			}else if("confirm".equals(oper)) {
				sql_data db = new sql_data();
				String id = req.getParameter("id");
				String sql = "delete from student where student_id = '"+id+"'";
				//System.out.println(sql);
				db.executeDelete(sql);
				resp.sendRedirect("./teacher/studentmanage.jsp");
			}else if("Confirm".equals(oper)) {
				sql_data db = new sql_data();
				String paper_id = req.getParameter("paper_id");
				String sql_paper = "delete from paper where paper_id = '"+paper_id+"'";
				String sql_paper_info = "delete from paper_info where paper_id = '"+paper_id+"'";
				db.executeDelete(sql_paper);
				db.executeDelete(sql_paper_info);
				resp.sendRedirect("./teacher/editing.jsp");
			}else  if("grade".equals(oper)) {
				upGrade(req,resp);
				resp.sendRedirect("./teacher/chosepaper.jsp");
			}else  if("addblank".equals(oper)) {
				addblank(req,resp);
				resp.sendRedirect("./teacher/question_manage.jsp");
			}else  if("addchose".equals(oper)) {
				addchose(req,resp);
				resp.sendRedirect("./teacher/question_manage.jsp");
			}else  if("changeblank".equals(oper)) {
				changeBlank(req,resp);
				resp.sendRedirect("./teacher/auditblank.jsp");
			}else if("deleteblank".equals(oper)) {
				deleteblank(req,resp);
				resp.sendRedirect("./teacher/auditblank.jsp");
			}else if("changechose".equals(oper)) {
				changeChose(req,resp);
				resp.sendRedirect("./teacher/auditchose.jsp");
			}else if("deletechose".equals(oper)) {
				deletechose(req,resp);
				resp.sendRedirect("./teacher/auditchose.jsp");
			}
		
	}

	private void deletechose(HttpServletRequest req, HttpServletResponse resp) {
		String chose_id=req.getParameter("id");
		String sql="delete from chose where chose_id='"+chose_id+"'";
		sql_data db=new sql_data();
		db.executeDelete(sql);
	}

	private void deleteblank(HttpServletRequest req, HttpServletResponse resp) {
		String blank_id=req.getParameter("id");
		String sql="delete from blank where blank_id='"+blank_id+"'";
		sql_data db=new sql_data();
		db.executeDelete(sql);
		
	}

	private void changeChose(HttpServletRequest req, HttpServletResponse resp) {
		String chose_id=req.getParameter("id");
		String question=req.getParameter("question");
		String A=req.getParameter("A");
		String B=req.getParameter("B");
		String C=req.getParameter("C");
		String D=req.getParameter("D");
		String answer=req.getParameter("answer");
		String sql="update chose set question='"+question+"',answer='"+answer+"',A='"+A+"',B='"+B+"',C='"+C+"',D='"+D+"' where chose_id='"+chose_id+"'";
		sql_data db=new sql_data();
		db.executeUpdate(sql);
	}

	private void changeBlank(HttpServletRequest req, HttpServletResponse resp) {
		String blank_id=req.getParameter("id");
		String question=req.getParameter("question");
		String answer=req.getParameter("answer");
		String sql="update blank set question='"+question+"',answer='"+answer+"' where blank_id='"+blank_id+"'";
		sql_data db=new sql_data();
		db.executeUpdate(sql);
	}

	private void addchose(HttpServletRequest req, HttpServletResponse resp) {
		String question=req.getParameter("question");
		String answer=req.getParameter("answer");
		String A=req.getParameter("A");
		String B=req.getParameter("B");
		String C=req.getParameter("C");
		String D=req.getParameter("D");
		String sql="insert into chose (question,answer,A,B,C,D)values('"+question+"','"+answer+"','"+A+"','"+B+"','"+C+"','"+D+"')";
		sql_data db=new sql_data();
		db.executeInsert(sql);
		
	}

	private void addblank(HttpServletRequest req, HttpServletResponse resp) {
		String question=req.getParameter("question");
		String answer=req.getParameter("answer");
		System.out.println(question+":"+answer);
		sql_data db=new sql_data();
		String sql="insert into blank values(default,'"+question+"','"+answer+"')";
		db.executeInsert(sql);
		
	}

	private void upGrade(HttpServletRequest req, HttpServletResponse resp) {
		HttpSession hs=req.getSession();
		String student_id=(String)hs.getAttribute("student_id");
		int chose_grade=(Integer)hs.getAttribute("chose_grade");
		int blank_grade=(Integer) hs.getAttribute("blank_grade");
		int fin_grade=(Integer) hs.getAttribute("fin_grade");
		ts.upGrade(Integer.parseInt(student_id),chose_grade,blank_grade,fin_grade);
	}

	private  Teacher login(HttpServletRequest req, HttpServletResponse resp) {
		String username=req.getParameter("username");
		String pwd=req.getParameter("password");
		return ts.Login(username, pwd);
	}

}
