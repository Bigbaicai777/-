package Dao;

import pojo.Teacher;

public interface TeaDao {
	public Teacher loginDao(String username,String pwd);//��ʦ��¼

	public void upGrade(int student_id,int chose_grade,int blank_grade, int fin_grade);
}
