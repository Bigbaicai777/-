package Dao;

import pojo.Student;

public interface StuDao {
	public Student loginDao(String username,String pwd);
	
}
