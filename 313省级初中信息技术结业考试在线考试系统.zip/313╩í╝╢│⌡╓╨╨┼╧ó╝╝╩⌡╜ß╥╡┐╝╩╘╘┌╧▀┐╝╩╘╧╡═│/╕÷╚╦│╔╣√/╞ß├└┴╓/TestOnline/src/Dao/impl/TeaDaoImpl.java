package Dao.impl;

import java.sql.*;

import Dao.TeaDao;
import pojo.Teacher;
import util.sql_data;

public class TeaDaoImpl implements TeaDao{
	//��ʦ��¼
	@Override
	public Teacher loginDao(String username, String pwd) {
		//����jdbc����
				Connection conn=null;
				PreparedStatement ps=null;
				ResultSet rs=null;
				//��������
				Teacher t=null;
				try {
					//��������
					Class.forName("com.mysql.jdbc.Driver");
					//��ȡ����
					conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/testonline","root", "990420");
					//����sql����
					String sql="select * from teacher where username=? and password=?";
					//����sql�������
					ps=conn.prepareStatement(sql);
					//��ռλ����ֵ
					ps.setString(1, username);
					ps.setString(2, pwd);
					//ִ��sql
					rs=ps.executeQuery();
					//�������
						while(rs.next()){
							//��������ֵ
							t=new Teacher();
							t.setName(rs.getString("name"));
							t.setPassword(rs.getString("password"));
							t.setTeacher_id(rs.getInt("teacher_id"));
							t.setUsername(rs.getString("username"));
						}
					
				} catch (Exception e) {
					e.printStackTrace();
				}finally{
					//�ر���Դ
					try {
						rs.close();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					try {
						ps.close();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					try {
						conn.close();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				
				
				//���ؽ��
				return t;
	}

	@Override
	public void upGrade(int student_id,int chose_grade,int blank_grade, int fin_grade) {
		sql_data db=new sql_data();
		String sql="update student set chose_grade="+chose_grade+",blank_grade="+blank_grade+",grade="+fin_grade+" where student.student_id="+student_id+"";
		db.executeUpdate(sql);
		/*
		 * //����jdbc���� Connection conn=null; Statement ps=null; ResultSet rs=null; //��������
		 * Teacher t=null; try { //�������� Class.forName("com.mysql.jdbc.Driver"); //��ȡ����
		 * conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/testonline",
		 * "root", "990420"); //����sql���� String
		 * sql="update student set grade="+grade+" where paper_id="+paper_id+""; //ִ��sql
		 * ps.execute(sql);
		 * 
		 * } catch (Exception e) { e.printStackTrace(); }finally{ try { ps.close(); }
		 * catch (SQLException e) { // TODO Auto-generated catch block
		 * e.printStackTrace(); } try { conn.close(); } catch (SQLException e) { // TODO
		 * Auto-generated catch block e.printStackTrace(); } }
		 */
				
	}
}