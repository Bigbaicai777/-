package pojo;

public class Paper {
	private int paper_id;//�Ծ����
	private int chose_id;
	private int black_id;
	private String student_ans;//������
	private int id;//����
	public int getPaper_id() {
		return paper_id;
	}
	public void setPaper_id(int paper_id) {
		this.paper_id = paper_id;
	}
	public int getChose_id() {
		return chose_id;
	}
	public void setChose_id(int chose_id) {
		this.chose_id = chose_id;
	}
	public int getBlack_id() {
		return black_id;
	}
	public void setBlack_id(int black_id) {
		this.black_id = black_id;
	}
	public String getStudent_ans() {
		return student_ans;
	}
	public void setStudent_ans(String student_ans) {
		this.student_ans = student_ans;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	@Override
	public String toString() {
		return "Paper [paper_id=" + paper_id + ", chose_id=" + chose_id + ", black_id=" + black_id + ", student_ans="
				+ student_ans + ", id=" + id + "]";
	}
	public Paper(int paper_id, int chose_id, int black_id, String student_ans, int id) {
		super();
		this.paper_id = paper_id;
		this.chose_id = chose_id;
		this.black_id = black_id;
		this.student_ans = student_ans;
		this.id = id;
	}
	public Paper() {
		super();
	}
	
}
