package pojo;

public class Student {
	private int student_id;
	private String username;//��¼��
	private String password;//��¼����
	private String name;//����
	private int grade;//ѧ���ĳɼ�
	private int paper_id;//ѧ�������Ծ�Id
	public int getStudent_id() {
		return student_id;
	}
	public void setStudent_id(int student_id) {
		this.student_id = student_id;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getGrade() {
		return grade;
	}
	public void setGrade(int grade) {
		this.grade = grade;
	}
	public int getPaper_id() {
		return paper_id;
	}
	public void setPaper_id(int paper_id) {
		this.paper_id = paper_id;
	}
	@Override
	public String toString() {
		return "Student [student_id=" + student_id + ", username=" + username + ", password=" + password + ", name="
				+ name + ", grade=" + grade + ", paper_id=" + paper_id + "]";
	}
	public Student() {
		super();
	}
	public Student(int student_id, String username, String password, String name, int grade, int paper_id) {
		super();
		this.student_id = student_id;
		this.username = username;
		this.password = password;
		this.name = name;
		this.grade = grade;
		this.paper_id = paper_id;
	}
	
}
