package Service;

import pojo.Student;

public interface StuService {
	public Student Login(String username,String pwd);
}
