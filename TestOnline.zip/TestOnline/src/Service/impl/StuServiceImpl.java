package Service.impl;

import Dao.*;
import Dao.impl.StuDaoImpl;
import Service.StuService;
import pojo.Student;

public class StuServiceImpl implements StuService{
	StuDao s=new StuDaoImpl();
	@Override
	public Student Login(String username, String pwd) {
		
		return s.loginDao(username, pwd);
	}

}
