package Service;

import pojo.Teacher;

public interface TeaService {
	public Teacher Login(String username,String pwd);


	public void upGrade(int student_id,int chose_grade,int blank_grade, int fin_grade);
	
}
