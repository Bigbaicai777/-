package Servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Service.StuService;
import Service.impl.StuServiceImpl;
import pojo.Student;
import util.sql_data;

/**
 * Servlet implementation class StuServlet
 */
@WebServlet("/StuServlet")
public class StuServlet extends HttpServlet {
	StuService s=new   StuServiceImpl();
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String oper=null;
		Student s=null;
		oper=req.getParameter("oper");
		oper = new String(oper.getBytes("ISO-8859-1"), "UTF-8"); 
		if ("login".equals(oper)) {
			// ��¼����
			s = login(req, resp);
			if (s != null) {
				HttpSession hs = req.getSession();
				hs.setAttribute("student", s);
				resp.sendRedirect("./student/main.jsp");
			} else {
				System.out.println("�˻����������");
			}
		} else if ("handin".equals(oper)) {
			int student_id = Integer.parseInt(req.getParameter("student_id"));
			int paper_id=Integer.parseInt(req.getParameter("paper_id"));
			String student_ansc[]=req.getParameterValues("student_ansc");
			
			String answer[]=new String[20];
			int i=0;
		    for(String ans:student_ansc) {
		    	
		    	answer[i]=ans;
		    //	System.out.println(answer[i]);
		    	i++;
		    }
		    
	        String sql="insert into answer_card values('"+paper_id+"','"+student_id+"','"+answer[0]+"','"+answer[1]+"','"+answer[2]+"','"+answer[3]+"','"+answer[4]+"','"+answer[5]+"','"+answer[6]+"','"+answer[7]+"','"+answer[8]+"','"+answer[9]+"','"+answer[10]+"','"+answer[11]+"','"+answer[12]+"','"+answer[13]+"','"+answer[14]+"','"+answer[15]+"','"+answer[16]+"','"+answer[17]+"','"+answer[18]+"','"+answer[19]+"',0)";
		    //System.out.println(sql);
		    sql_data db = new sql_data();
			db.executeInsert(sql);
			resp.sendRedirect("./student/finish.jsp");
		}
	}
	private Student login(HttpServletRequest req, HttpServletResponse resp) {
		String username=req.getParameter("username");
		String pwd=req.getParameter("password");
		return s.Login(username, pwd);
		
	}
	


}
