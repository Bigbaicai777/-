package Servlet;


import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import pojo.*;
import util.sql_data;
import java.sql.*;
/**
 * Servlet implementation class ETServlet
 */
@WebServlet("/ETServlet")
public class ETServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ETServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

  @Override
protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	// TODO Auto-generated method stub

	String paper_id = null;
	String teacher_id = null;
	String start_time = null;
	String end_time= null;
	String oper=null;
	ResultSet rs=null;
	int id = 0;
	String score = null;
	request.setCharacterEncoding("utf-8");
	response.setContentType("text/html;charset=utf-8");
	
	oper = request.getParameter("oper");   
	//Integer paper_id = request.getParameter("paper_id") != null && !request.getParameter("paper_id").equals("") ? Integer.parseInt(request.getParameter("paper_id")) : null;
	paper_id = request.getParameter("p_id");
	teacher_id = request.getParameter("t_id");
	start_time = request.getParameter("s_time");
	end_time = request.getParameter("e_time");
	String paper_name = request.getParameter("papername");
	//System.out.println(oper+paper_name);
		if ("ETtest".equals(oper)) {
			if (paper_id != null && paper_name != null && start_time != null && teacher_id != null
					&& end_time != null) {
				System.out.println(paper_id + paper_name + start_time + teacher_id + end_time);
				String sql = "insert into paper_info values('" + paper_id + "','" + paper_name + "','" + start_time
						+ "','" + teacher_id + "','" + end_time + "')";
				sql_data db1 = new sql_data();
				db1.executeInsert(sql);
				String sql2 = "select * from student ";
				rs = db1.executeQuery(sql2);
				try {
					if (rs == null) {
						System.out.print("rsΪ��");
					} else {
						while (rs.next()) {
							String stu_id = rs.getString("student_id");
							id = Distribution();
							String sql3 = "update student set paper_id='" + id + "' where student_id='" + stu_id + "'";
							db1.executeUpdate(sql3);
						}
					}
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} /*	Student stu=null;	
				List<Student> s = new ArrayList<Student>();
				String sql2 ="select student_id from student ";
				 ResultSet rs2=null;
				rs2=db1.executeQuery(sql2);
				try {
					while(rs2.next()) {
						stu=new Student();
						int s_id=Integer.parseInt(rs2.getString("student_id"));
						stu.setStudent_id(s_id);
						s.add(stu);
					}
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				for(Student t:s) {
					
				}*/
				response.sendRedirect("./teacher/main.jsp");
				return;
				}
				
			 else {
				System.out.println("û������");
				response.sendRedirect("./teacher/EditTest.jsp");
			}
}
	else if ("SScore".equals(oper)) {

		//System.out.println(paper_name);
		if (paper_name != null) {
			String sql = "select student_id,name,grade,paper_name,graduation from student , paper_info where student.paper_id=paper_info.paper_id and paper_name='"
					+ paper_name + "'";
			sql_data db = new sql_data();
			rs = db.executeQuery(sql);
			HttpSession hs = request.getSession();
			hs.setAttribute("rs", rs);
			response.sendRedirect("./teacher/list.jsp");
			return;

		}
	}
}
 public int Distribution(){

		String sql = "SELECT COUNT(distinct paper_id) AS count1 FROM student";
		sql_data db = new sql_data();
		ResultSet rs = db.executeQuery(sql);
		int count = -1;
		try {
			if(rs.next())
			count = Integer.parseInt(rs.getString("count1"));
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		int random = 0;
		random = (int) (1 + Math.random() * (count));
		return random;
	}
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */

}
