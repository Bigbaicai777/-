package Dao.impl;

import java.sql.*;

import Dao.StuDao;
import pojo.Student;

public class StuDaoImpl implements StuDao{

	@Override
	public Student loginDao(String username, String pwd) {
		
		//����jdbc����
				Connection conn=null;
				PreparedStatement ps=null;
				ResultSet rs=null;
				//��������
				Student s=new Student();
				try {
					//��������
					Class.forName("com.mysql.jdbc.Driver");
					//��ȡ����
					conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/testonline","root", "990420");
					//����sql����
					String sql="select * from student where username=? and password=?";
					//����sql�������
					ps=conn.prepareStatement(sql);
					//��ռλ����ֵ
					ps.setString(1, username);
					ps.setString(2, pwd);
					//ִ��sql
					rs=ps.executeQuery();
					//�������
					
						while(rs.next()){
							//��������ֵ
							s.setUsername(rs.getString("username"));
							s.setGrade(rs.getInt("grade"));
							s.setPassword(rs.getString("password"));
							s.setStudent_id(rs.getInt("student_id"));
							s.setPaper_id(rs.getInt("paper_id"));
							s.setName(rs.getString("name"));
							
						}
					
				} catch (Exception e) {
					e.printStackTrace();
				}finally{
					//�ر���Դ
					try {
						rs.close();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					try {
						ps.close();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					try {
						conn.close();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				
				
				//���ؽ��
				return s;
	}

}
